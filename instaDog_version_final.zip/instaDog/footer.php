


<footer class="page-footer font-small teal fixed-bottom">
    <div class="footer-copyright text-center py-3 footerCopy bg-dark">InstaDog <i class="far fa-copyright"></i> 2019 Copyright: Adrien & Gutemberg
      <a href="galeriePhoto.php">www.InstaDog.ch</a>
    </div>
</footer>
